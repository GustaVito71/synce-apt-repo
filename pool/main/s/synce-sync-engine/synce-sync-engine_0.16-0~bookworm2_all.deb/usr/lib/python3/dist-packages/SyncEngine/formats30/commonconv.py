# -*- coding: utf-8 -*-
############################################################################
# COMMONCONV.py
#
# Dr J A Gow 10/11/2007
#
# XSLT extensions common to more than one sync item
#
############################################################################

from lxml import etree
import pyrtfcomp
import base64
from time import gmtime, strftime
from . import tzutils
from . import tzdatabase
from . import dateutil
import SyncEngine.xml2util as xml2util

# exactly what it says on the tin.

MINUTES_PER_HOUR    = 60
MINUTES_PER_DAY     = MINUTES_PER_HOUR * 24

# Date formats

DATE_FORMAT_EVENT         = '%Y%m%dT%H%M%SZ'
DATE_FORMAT_SHORT         = '%Y%m%d'

# Compressed RTF header

RTFHDR = "\\ansi \\deff0{\\fonttbl{\\f0\\fnil\\fcharset0\\fprq0 Tahoma;}{\\f1\\froman\\fcharset2\\fprq2 "
RTFHDR += "Symbol;}{\\f2\\fswiss\\fcharset204\\fprq2  ;}}{\\colortbl;\\red0\\green0\\blue0;\\red128\\green128"
RTFHDR += "\\blue128;\\red192\\green192\\blue192;\\red255\\green255\\blue255;\\red255\\green0\\blue0;\\red0"
RTFHDR += "\\green255\\blue0;\\red0\\green0\\blue255;\\red0\\green255\\blue255;\\red255\\green0\\blue255;"
RTFHDR += "\\red255\\green255\\blue0;\\red128\\green0\\blue0;\\red0\\green128\\blue0;\\red0\\green0"
RTFHDR += "\\blue128;\\red0\\green128\\blue128;\\red128\\green0\\blue128;\\red128\\green128\\blue0;}\x0a\x0d"
RTFHDR += "\\f0 \\fs16 "

VCALDAYSTOASDAYS         = { "SU" : 1,
                                  "MO" : 2,
                                  "TU" : 4,
                                  "WE" : 8,
                                  "TH" : 16,
                                  "FR" : 32,
                                  "SA" : 64 }

ASDAYSTOVCALDAYS =              {  1   : "SU",
                                   2   : "MO",
                                   4   : "TU",
                                   8   : "WE",
                                   16  : "TH",
                                   32  : "FR",
                                   64  : "SA" }


###############################################################################
# VcalDaysToAirsyncDays
#
# Utility function not called directly by XSLT transforms

def VcalDaysToAirsyncDays(vcal_days):
    airsync_days = 0
    for vcal_day in vcal_days.split(","):
        airsync_days = airsync_days | VCALDAYSTOASDAYS[vcal_day.upper()]
    return airsync_days

###############################################################################
# AirsyncDaysToVcalDays
#
# Utility function not called directly by XSLT transforms

def AirsyncDaysToVcalDays(airsync_days):
    vcal_days = []
    for i in range(0,8):
        mask = (1 << i)
        if mask & int(airsync_days):
            vcal_days.append(ASDAYSTOVCALDAYS[mask])
    return ",".join(vcal_days)

###############################################################################
# GenerateVcalByDay
#
# Utility function not called directly by XSLT transforms

def GenerateVcalByDay(airsync_week, airsync_day):
    week = int(airsync_week)
    if week == 5:
        # Special case: Airsync uses '5' to denote the last week of a month
        week = -1
    return "%d%s" % (week, ASDAYSTOVCALDAYS[int(airsync_day)])

###############################################################################
# VcalSplitByDay utility

def VcalSplitByDay(vcal_byday):
    return (vcal_byday[:-2], vcal_byday[-2:])


###############################################################################
# _HandleOSTZ (Cat.A)
#
# Handle an Opensync <Timezone> element.

def _HandleOSTZ(context):
    tznode = context.context_node
    tzdatabase.NewTZFromXML(tznode, tzdatabase.tzdb)
    return ""

###############################################################################
# _HandleOSTZComponent (Cat.A)
#
# Handle an Opensync <TimezoneComponent> element.

def _HandleOSTZComponent(context):
    tznode = context.context_node
    tzdatabase.NewTZComponentFromXML(tznode, tzdatabase.tzdb)
    return ""

###############################################################################
# _HandleOSTZRRule (Cat.A)
#
# Handle an Opensync <TimezoneRule> element.

def _HandleOSTZRRule(context):
    tznode = context.context_node
    tzdatabase.NewTZRRuleFromXML(tznode, tzdatabase.tzdb)
    return ""

###############################################################################
# _CurrentTZToAirsyncExt (Cat.B)

class _CurrentTZToAirsyncExt(etree.XSLTExtension):
    def execute(self, context, self_node, input_node, output_parent):
        tz = tzdatabase.tzdb.GetCurrentTimezone()
        if tz is not None:
            ns = "http://synce.org/formats/airsync_wm5/calendar"
            tznode = etree.Element("{%s}Timezone" % ns)
            tznode.text = base64.b64encode(tzdatabase.TZToAirsync(tz)).decode()
            output_parent.append(tznode)

###############################################################################
# _TZFromAirsync (Cat.A)
#
# Load an AirSync timezone into the database

def _TZFromAirsync(context):
    import datetime
    tznode = context.context_node
    tzdata = base64.b64decode(xml2util.GetNodeValue(tznode))

    # Some AS timezones fail to include a year. See if we can
    # graft this from the AS body

    datenode = xml2util.FindChildNode(tznode.getparent(), "StartTime")
    if datenode is None:
        datenode = xml2util.FindChildNode(tznode.getparent(), "DtStamp")
    if datenode is None:
        year = datetime.datetime.now().year
    else:
        txtyear = xml2util.GetNodeValue(datenode)
        year = int(txtyear[0:4])

    tz = tzdatabase.TZFromAirsync(tzdata, year)

    if tz is not None:
        tzdatabase.tzdb.PutTimezone(tz)

    return ""

###############################################################################
# _AllTZToOpensyncExt (Cat.B)

class _AllTZToOpensyncExt(etree.XSLTExtension):
    def execute(self, context, self_node, input_node, output_parent):
        tzs = tzdatabase.tzdb.GetTimezoneList()
        for tz in tzs:
            tmp = etree.Element("_tmp")
            tzdatabase.TZToXML(tmp, tzdatabase.tzdb.GetTimezone(tz))
            for child in list(tmp):
                output_parent.append(child)

###############################################################################
# _OSDateToAirsync (Cat.A)
#
# Convert an OpenSync date to an AirSync date.

def _OSDateToAirsync(context):
    tznode = context.context_node
    date = dateutil.XMLDateTimeToDate(tznode, tzdatabase.tzdb)
    utcdate = date.astimezone(tzutils.tzone.utc)
    return utcdate.strftime(DATE_FORMAT_EVENT)

###############################################################################
# _OSDateFromAirsyncExt (Cat.B)

class _OSDateFromAirsyncExt(etree.XSLTExtension):
    def execute(self, context, self_node, input_node, output_parent):
        date = dateutil.TextToDate(xml2util.GetNodeValue(input_node))
        date = date.replace(tzinfo=tzutils.tzone.utc)

        curtz = tzdatabase.tzdb.GetCurrentTimezone()
        if curtz is not None:
            date = date.astimezone(curtz)

        content = etree.Element("Content")
        content.text = date.strftime(DATE_FORMAT_EVENT)
        output_parent.append(content)

###############################################################################
# _AirsyncDateFromNow (Cat.A)

def _AirsyncDateFromNow(context):
    return strftime("%Y%m%dT%H%M%SZ", gmtime())

###############################################################################
# _OSTextToAirsyncRTF (Cat.A)
#
# Encodes standard text to the compressed-RTF used by AirSync

def _OSTextToAirsyncRTF(context):
    s = xml2util.GetNodeValue(context.context_node)
    ec = ""
    if len(s) > 0:
        try:
            asnote = pyrtfcomp.RTFConvertFromUTF8(s, RTFHDR, 1)
            ec = base64.b64encode(asnote).decode()
        except pyrtfcomp.RTFException:
            pass
    return ec

###############################################################################
# _OSTextFromAirsyncRTF (Cat.A)
#
# Converts Airsync RTF content to standard text

def _OSTextFromAirsyncRTF(context):
    s = xml2util.GetNodeValue(context.context_node)
    asnote = ""
    if len(s) > 0:
        dc = base64.b64decode(s)
        try:
            asnote = pyrtfcomp.RTFConvertToUTF8(dc, 1)
        except pyrtfcomp.RTFException:
            pass
    return asnote

###############################################################################
# _RecurrenceRuleToAirsyncExt (Cat.B)

class _RecurrenceRuleToAirsyncExt(etree.XSLTExtension):
    def execute(self, context, self_node, input_node, output_parent):
        tmp = etree.Element("_tmp")
        _RecurrenceRuleToAirsync(input_node, tmp)
        for child in list(tmp):
            output_parent.append(child)

def _RecurrenceRuleToAirsync(input_node, output_parent):
    src_node = input_node

    # Extract the rules from child elements
    src_rules = {}
    for child in src_node:
        if isinstance(child.tag, str):
            src_rules[xml2util._local_name(child.tag).lower()] = xml2util.GetNodeValue(child)

    if "interval" in src_rules:
        etree.SubElement(output_parent, "Interval").text = src_rules["interval"]
    if "until" in src_rules:
        etree.SubElement(output_parent, "Until").text = dateutil.TextToDate(src_rules["until"]).strftime(DATE_FORMAT_EVENT)
    if "count" in src_rules:
        etree.SubElement(output_parent, "Occurrences").text = src_rules["count"]

    if src_rules["frequency"].lower() == "daily":
        etree.SubElement(output_parent, "Type").text = "0"

    elif src_rules["frequency"].lower() == "weekly":
        etree.SubElement(output_parent, "Type").text = "1"
        etree.SubElement(output_parent, "DayOfWeek").text = str(VcalDaysToAirsyncDays(src_rules["byday"]))

    elif src_rules["frequency"].lower() == "monthly":
        if "bymonthday" in src_rules:
            etree.SubElement(output_parent, "Type").text = "2"
            etree.SubElement(output_parent, "DayOfMonth").text = src_rules["bymonthday"]
        elif "byday" in src_rules:
            week, day = VcalSplitByDay(src_rules["byday"])
            etree.SubElement(output_parent, "Type").text = "3"
            etree.SubElement(output_parent, "DayOfWeek").text = str(VcalDaysToAirsyncDays(day))
            if int(week) >= 0:
                etree.SubElement(output_parent, "WeekOfMonth").text = week
            elif int(week) == -1:
                etree.SubElement(output_parent, "WeekOfMonth").text = "5"
            else:
                raise ValueError("Airsync does not support counting from end of month")
        else:
            raise ValueError("Monthly events must either specify BYMONTHDAY or BYDAY rules")

    elif src_rules["frequency"].lower() == "yearly":
        if "bymonth" in src_rules:
            if "bymonthday" in src_rules:
                etree.SubElement(output_parent, "Type").text = "5"
                etree.SubElement(output_parent, "MonthOfYear").text = src_rules["bymonth"]
                etree.SubElement(output_parent, "DayOfMonth").text = src_rules["bymonthday"]
            elif "byday" in src_rules:
                week, day = VcalSplitByDay(src_rules["byday"])
                etree.SubElement(output_parent, "Type").text = "6"
                etree.SubElement(output_parent, "MonthOfYear").text = src_rules["bymonth"]
                etree.SubElement(output_parent, "DayOfWeek").text = str(VcalDaysToAirsyncDays(day))
                if int(week) >= 0:
                    etree.SubElement(output_parent, "WeekOfMonth").text = week
                elif int(week) == -1:
                    etree.SubElement(output_parent, "WeekOfMonth").text = "5"
                else:
                    raise ValueError("Airsync does not support counting from end of month")
            else:
                raise ValueError("Yearly events which are by month must either specify BYMONTHDAY or BYDAY rules")
        elif "byyearday" in src_rules:
            raise ValueError("Airsync does not support day-of-year yearly events")
        else:
            start = xml2util.FindChildNode(src_node.getparent(), "DateStarted")
            date = dateutil.XMLDateTimeToDate(start, tzdatabase.tzdb)
            utcdate = date.astimezone(tzutils.tzone.utc)
            etree.SubElement(output_parent, "Type").text = "5"
            etree.SubElement(output_parent, "MonthOfYear").text = str(utcdate.month)
            etree.SubElement(output_parent, "DayOfMonth").text = str(utcdate.day)

###############################################################################
# _RecurrenceRuleFromAirsyncExt (Cat.B)

class _RecurrenceRuleFromAirsyncExt(etree.XSLTExtension):
    def execute(self, context, self_node, input_node, output_parent):
        tmp = etree.Element("_tmp")
        _RecurrenceRuleFromAirsync(input_node, tmp)
        for child in list(tmp):
            output_parent.append(child)

def _RecurrenceRuleFromAirsync(input_node, output_parent):
    src_node = input_node

    interval_node    = xml2util.FindChildNode(src_node, "Interval")
    until_node       = xml2util.FindChildNode(src_node, "Until")
    occurrences_node = xml2util.FindChildNode(src_node, "Occurrences")
    type_node        = xml2util.FindChildNode(src_node, "Type")
    dayofweek_node   = xml2util.FindChildNode(src_node, "DayOfWeek")
    dayofmonth_node  = xml2util.FindChildNode(src_node, "DayOfMonth")
    weekofmonth_node = xml2util.FindChildNode(src_node, "WeekOfMonth")
    monthofyear_node = xml2util.FindChildNode(src_node, "MonthOfYear")

    if until_node is not None:
        etree.SubElement(output_parent, "Until").text = xml2util.GetNodeValue(until_node)
    if occurrences_node is not None:
        etree.SubElement(output_parent, "Count").text = xml2util.GetNodeValue(occurrences_node)
    if interval_node is not None:
        etree.SubElement(output_parent, "Interval").text = xml2util.GetNodeValue(interval_node)

    if type_node is not None:
        rtype = int(xml2util.GetNodeValue(type_node))

        if rtype == 0 and dayofweek_node is not None:
            rtype = 1

        if rtype == 0:
            etree.SubElement(output_parent, "Frequency").text = "DAILY"
        elif rtype == 1:
            etree.SubElement(output_parent, "Frequency").text = "WEEKLY"
            etree.SubElement(output_parent, "ByDay").text = AirsyncDaysToVcalDays(xml2util.GetNodeValue(dayofweek_node))
        elif rtype == 2:
            etree.SubElement(output_parent, "Frequency").text = "MONTHLY"
            etree.SubElement(output_parent, "ByMonthDay").text = xml2util.GetNodeValue(dayofmonth_node)
        elif rtype == 3:
            etree.SubElement(output_parent, "Frequency").text = "MONTHLY"
            etree.SubElement(output_parent, "ByDay").text = GenerateVcalByDay(xml2util.GetNodeValue(weekofmonth_node), xml2util.GetNodeValue(dayofweek_node))
        elif rtype == 5:
            etree.SubElement(output_parent, "Frequency").text = "YEARLY"
            etree.SubElement(output_parent, "ByMonth").text = xml2util.GetNodeValue(monthofyear_node)
            etree.SubElement(output_parent, "ByMonthDay").text = xml2util.GetNodeValue(dayofmonth_node)
        elif rtype == 6:
            etree.SubElement(output_parent, "Frequency").text = "YEARLY"
            etree.SubElement(output_parent, "ByMonth").text = xml2util.GetNodeValue(monthofyear_node)
            etree.SubElement(output_parent, "ByDay").text = GenerateVcalByDay(xml2util.GetNodeValue(weekofmonth_node), xml2util.GetNodeValue(dayofweek_node))
        else:
            raise ValueError("Unknown recurrence type %d from Airsync" % rtype)
    else:
        raise ValueError("No recurrence type specified from Airsync")

###############################################################################
# _ClassToAirsync (Cat.A)

def _ClassToAirsync(context):
    s = xml2util.GetNodeValue(context.context_node)
    if s == "PRIVATE":
        return "2"
    elif s == "CONFIDENTIAL":
        return "3"
    else:
        return "0"

###############################################################################
# _ClassFromAirsync (Cat.A)

def _ClassFromAirsync(context):
    s = xml2util.GetNodeValue(context.context_node)
    if s == "2":
        return "PRIVATE"
    elif s == "3":
        return "CONFIDENTIAL"
    else:
        return "PUBLIC"

###############################################################################
# _AlarmToAirsync (Cat.A)

def _AlarmToAirsync(context):
    src_node = context.context_node

    value_node = xml2util.GetNodeAttr(src_node, "Value")

    if value_node is None:
        return ""
    if value_node.lower() != "duration":
        return ""

    content_node = xml2util.FindChildNode(src_node, "AlarmTrigger")
    s = xml2util.GetNodeValue(content_node).lstrip("-PT").upper()

    days = 0
    hours = 0
    minutes = 0

    if s.rfind("D") != -1:
        days = int(s[:s.rfind("D")])
        s = s[s.rfind("D")+1:]
    if s.rfind("H") != -1:
        hours = int(s[:s.rfind("H")])
        s = s[s.rfind("H")+1:]
    if s.rfind("M") != -1:
        minutes = int(s[:s.rfind("M")])
        s = s[s.rfind("M")+1:]

    return str(days * MINUTES_PER_DAY + hours * MINUTES_PER_HOUR + minutes)

###############################################################################
# _CurrentTZName (Cat.A)
#
# Returns the name of the current timezone, or empty string if none.

def _CurrentTZName(context):
    tz = tzdatabase.tzdb.GetCurrentTimezone()
    return tz.name if tz is not None else ""

###############################################################################
# _AlarmFromAirsync (Cat.A)

def _AlarmFromAirsync(context):
    s = int(xml2util.GetNodeValue(context.context_node))
    if s % MINUTES_PER_DAY == 0:
        return "-P%iD" % (s // MINUTES_PER_DAY)
    elif s % MINUTES_PER_HOUR == 0:
        return "-PT%iH" % (s // MINUTES_PER_HOUR)
    else:
        return "-PT%iM" % s

###############################################################################
# register_xpath_functions
#
# Register Cat.A common converter functions via lxml FunctionNamespace

def register_xpath_functions():
    ns = etree.FunctionNamespace("http://synce.org/common")
    ns.prefix = "common"
    ns["HandleOSTZ"]           = _HandleOSTZ
    ns["HandleOSTZComponent"]  = _HandleOSTZComponent
    ns["HandleOSTZRule"]       = _HandleOSTZRRule
    ns["TZFromAirsync"]        = _TZFromAirsync
    ns["OSDateToAirsync"]      = _OSDateToAirsync
    ns["AirsyncDateFromNow"]   = _AirsyncDateFromNow
    ns["OSTextToAirsyncRTF"]   = _OSTextToAirsyncRTF
    ns["OSTextFromAirsyncRTF"] = _OSTextFromAirsyncRTF
    ns["ClassToAirsync"]       = _ClassToAirsync
    ns["ClassFromAirsync"]     = _ClassFromAirsync
    ns["AlarmToAirsync"]       = _AlarmToAirsync
    ns["AlarmFromAirsync"]     = _AlarmFromAirsync
    ns["CurrentTZName"]        = _CurrentTZName

###############################################################################
# get_extension_elements
#
# Returns Cat.B extension element classes (populated in Fase 2b)

def get_extension_elements():
    return {
        ("http://synce.org/common", "CurrentTZToAirsync"):        _CurrentTZToAirsyncExt(),
        ("http://synce.org/common", "AllTZToOpensync"):            _AllTZToOpensyncExt(),
        ("http://synce.org/common", "OSDateFromAirsync"):          _OSDateFromAirsyncExt(),
        ("http://synce.org/common", "RecurrenceRuleToAirsync"):    _RecurrenceRuleToAirsyncExt(),
        ("http://synce.org/common", "RecurrenceRuleFromAirsync"):  _RecurrenceRuleFromAirsyncExt(),
    }
