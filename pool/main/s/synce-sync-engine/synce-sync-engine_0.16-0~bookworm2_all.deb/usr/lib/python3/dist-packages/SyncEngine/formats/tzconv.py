# -*- coding: utf-8 -*-
############################################################################
# TZCONV.py
#
# Timezone conversion utilities
#
# Dr J A Gow 29/3/2007
#
############################################################################

from lxml import etree
import struct
import datetime
from . import tzutils
import SyncEngine.xml2util as xml2util
import base64
import SyncEngine.util
import calendar

# The global timezone database. This exists for the runtime life of a
# sync-engine session and is updated when necessary/

TZDB = {}
CUR_TZ = {"current":None}


class ASTimezoneData:

    def __init__(self):
        self._zero()
        self.tzcurrent = None

    def _zero(self):
        self.bias = 0
        self.std_name = ""
        self.std_year = 0
        self.std_month = 0
        self.std_dow = 0
        self.std_occurrence = 0
        self.std_start_hour = 0
        self.std_minute = 0
        self.std_second = 0
        self.std_millisecs = 0
        self.std_bias = 0
        self.dst_name = ""
        self.dst_year = 0
        self.dst_month = 0
        self.dst_dow = 0
        self.dst_occurrence = 0
        self.dst_start_hour = 0
        self.dst_minute = 0
        self.dst_second = 0
        self.dst_millisecs = 0
        self.dst_bias = 0

    def dump(self):

        print(("bias             %d" % self.bias))
        print(("std_name         %s" % self.std_name))
        print(("std_year         %d" % self.std_year))
        print(("std_month        %d" % self.std_month))
        print(("std_dow          %d" % self.std_dow))
        print(("std_occurrence   %d" % self.std_occurrence))
        print(("std_start_hour   %d" % self.std_start_hour))
        print(("std_minute       %d" % self.std_minute))
        print(("std_second       %d" % self.std_second))
        print(("std_millisecs    %d" % self.std_millisecs))
        print(("std_bias         %d" % self.std_bias))
        print(("dst_name        %s" % self.dst_name))
        print(("dst_month        %d" % self.dst_month))
        print(("dst_dow          %d" % self.dst_dow))
        print(("dst_occurrence   %d" % self.dst_occurrence))
        print(("dst_start_hour   %d" % self.dst_start_hour))
        print(("dst_minute       %d" % self.dst_minute))
        print(("dst_second       %d" % self.dst_second))
        print(("dst_millisecs    %d" % self.dst_millisecs))
        print(("dst_bias         %d" % self.dst_bias))

    def UnpackFromAirsync(self, stream):

        (self.bias,
         stdname,
         self.std_year, self.std_month, stddow,
         self.std_occurrence, self.std_start_hour, self.std_minute, self.std_second,
         self.std_millisecs, self.std_bias,
         dstname,
         self.dst_year, self.dst_month, dstdow,
         self.dst_occurrence, self.dst_start_hour, self.dst_minute, self.dst_second,
         self.dst_millisecs, self.dst_bias) =  struct.unpack("<i64shhhhhhhhi64shhhhhhhhi",stream)

        self.std_name = SyncEngine.util.decode_wstr(stdname)
        self.std_dow = (stddow + 6) % 7
        self.dst_name = SyncEngine.util.decode_wstr(dstname)
        self.dst_dow = (dstdow + 6) % 7

        if self.std_name == "":
            self.std_name = "STD"
        if self.dst_name == "":
            self.dst_name = "DST"

    def PackToAirsync(self):

        stdname = SyncEngine.util.encode_wstr(self.std_name)
        dstname = SyncEngine.util.encode_wstr(self.dst_name)
        stddow = (self.std_dow - 6) % 7
        dstdow = (self.dst_dow - 6) % 7

        return struct.pack("<i64shhhhhhhhi64shhhhhhhhi",
                    self.bias,
                                stdname,
                    self.std_year, self.std_month, stddow,
                    self.std_occurrence, self.std_start_hour, self.std_minute, self.std_second,
                    self.std_millisecs, self.std_bias,
                    dstname,
                    self.dst_year, self.dst_month, dstdow,
                    self.dst_occurrence, self.dst_start_hour, self.dst_minute, self.dst_second,
                    self.dst_millisecs, self.dst_bias)

    def FromVcalTZ(self,tz):

        self._zero()

        if tz.stdoffset < datetime.timedelta(0):
            stdos = -tz.stdoffset
        else:
            stdos = tz.stdoffset

        if len(tz.stdRecurrence.byDay) > 0:
            self.bias = stdos.days * 24 * 60 + stdos.seconds//60
            if len(tz.stdRecurrence.byMonth) > 0:
                self.std_month = tz.stdRecurrence.byMonth[0]
            else:
                self.std_month = tz.stdRecurrence.startdate.month
            day,pos = tz.stdRecurrence.byDay[0]
            d = pos
            if d < 0:
                d = 5
            self.std_dow = day
            self.std_occurrence = d
            self.std_hour = tz.stdRecurrence.startdate.hour
            self.std_minute = tz.stdRecurrence.startdate.minute

            if len(tz.dstRecurrence.byDay) > 0:

                os_dst = -tz.dstoffset
                self.dst_bias = os_dst.days * 24 * 60 + os_dst.seconds//60
                if len(tz.dstRecurrence.byMonth) > 0:
                    self.dst_month = tz.dstRecurrence.byMonth[0]
                else:
                    self.dst_month = tz.dstRecurrence.startdate.month
                day,pos = tz.dstRecurrence.byDay[0]
                d=pos
                if d < 0:
                    d = 5
                self.dst_dow = day
                self.dst_occurrence = d
                self.dst_hour=tz.dstRecurrence.startdate.hour
                self.dst_minute = tz.dstRecurrence.startdate.minute

    def ToVcalTZ(self, node, year):

        #
        # Now, if we do not have a DST definition, then the timezone
        # field is of no use to us as we can not just specify offsets. So
        # do not generate anything if the self.dst_month or self.std_month
        # is zero.

        if self.dst_month!=0 and self.std_month!=0:

            # Calculate year and day values for DST

            dst_sd = self.dst_occurrence
            dst_sy = self.dst_year

            if self.dst_year == 0:

                # we need to calculate the date from the month and year.

                d = datetime.datetime(year,self.dst_month,1,0,0,0)
                wd,ndays = calendar.monthrange(year,self.dst_month)
                dd = datetime.timedelta(days=1)
                while wd!=self.dst_dow:
                    d+=dd
                    wd = d.weekday()
                oc=1
                dd = datetime.timedelta(days=7)
                while oc < self.dst_occurrence:
                    d  += dd
                    oc += 1
                    if (ndays - d.day) < 7:
                        break
                dst_sd = d.day
                dst_sy = year

            # Calculate year and day values for STD

            std_sd = self.std_occurrence
            std_sy = self.std_year

            if self.std_year == 0:

                # we need to calculate the date from the month and year.

                d = datetime.datetime(year,self.std_month,1,0,0,0)
                wd,ndays = calendar.monthrange(year,self.std_month)
                dd = datetime.timedelta(days=1)
                while wd!=self.std_dow:
                    d+=dd
                    wd = d.weekday()
                oc=1
                dd = datetime.timedelta(days=7)
                while oc < self.std_occurrence:
                    d  += dd
                    oc += 1
                    if (ndays - d.day) < 7:
                        break
                std_sd = d.day
                std_sy = year

            #
            # The timezone ID (for vcal)

            tzid = "/synce.org/DST-%02d%02d%02dT%02d%02d%02d-STD-%02d%02d%02dT%02d%02d%02d" \
                   % (self.dst_month,
                      self.dst_dow,self.dst_occurrence,
                      self.dst_start_hour,self.dst_minute,self.dst_second,
                      self.std_month,
                      self.std_dow,self.std_occurrence,
                      self.std_start_hour,self.std_minute,self.std_second)

            # Build the document using lxml.

            tznode = etree.SubElement(node, "Timezone")

            etree.SubElement(tznode, "TimezoneID").text = tzid
            etree.SubElement(tznode, "Location").text = "Unknown/Unknown"

            dstnode = etree.SubElement(tznode, "DaylightSavings")
            osf = "%+03d%02d" % (-self.bias/60, self.dst_minute)
            etree.SubElement(dstnode, "TZOffsetFrom").text = osf
            ost = "%+03d%02d" % (-(self.bias/60 + self.dst_bias/60), self.dst_minute)
            etree.SubElement(dstnode, "TZOffsetTo").text = ost
            etree.SubElement(dstnode, "TimezoneName").text = self.dst_name

            ds = "%4d%02d%02dT%02d%02d%02d" % (dst_sy, self.dst_month, dst_sd,
                                               self.dst_start_hour, self.dst_minute,
                                               self.dst_second)
            etree.SubElement(dstnode, "DateStarted").text = ds
            dst_rr = etree.SubElement(dstnode, "RecurrenceRule")
            etree.SubElement(dst_rr, "Rule").text = "FREQ=YEARLY"
            etree.SubElement(dst_rr, "Rule").text = "INTERVAL=1"
            etree.SubElement(dst_rr, "Rule").text = "BYMONTH=%d" % self.dst_month

            d = self.dst_occurrence
            if d == 5:
                d = -1
            etree.SubElement(dst_rr, "Rule").text = "BYDAY=%d%s" % (d, tzutils.dowtxt[self.dst_dow])

            stdnode = etree.SubElement(tznode, "Standard")
            osf = "%+03d%02d" % (-(self.bias/60 + self.dst_bias/60), self.dst_minute)
            etree.SubElement(stdnode, "TZOffsetFrom").text = osf
            ost = "%+03d%02d" % (-self.bias/60, self.dst_minute)
            etree.SubElement(stdnode, "TZOffsetTo").text = ost
            etree.SubElement(stdnode, "TimezoneName").text = self.std_name

            ds = "%4d%02d%02dT%02d%02d%02d" % (std_sy, self.std_month, std_sd,
                                               self.std_start_hour, self.std_minute,
                                               self.std_second)
            etree.SubElement(stdnode, "DateStarted").text = ds
            std_rr = etree.SubElement(stdnode, "RecurrenceRule")
            etree.SubElement(std_rr, "Rule").text = "FREQ=YEARLY"
            etree.SubElement(std_rr, "Rule").text = "INTERVAL=1"
            etree.SubElement(std_rr, "Rule").text = "BYMONTH=%d" % self.std_month

            d = self.std_occurrence
            if d == 5:
                d = -1
            etree.SubElement(std_rr, "Rule").text = "BYDAY=%d%s" % (d, tzutils.dowtxt[self.std_dow])

            # Now, we can generate a new actual timezone based on this.

            self.tzcurrent = tzutils.tzone.TZInfoFromVcal(tznode)

            print(("CONFIG - DST OFFSET ", self.tzcurrent.dstoffset))


def FindASDateElementContent(doc,element):

    up = xml2util.FindChildNode(doc,element)
    if up != None:
        return xml2util.GetNodeValue(up)
    else:
        return None


def curtz():
    return CUR_TZ["current"]

###############################################################################
# _ConvertASTimezoneToVcalExt (Cat.B)
#
# Take an AS timezone, if fully specified, and convert it to a valid
# (but unknown) VCAL timezone.

class _ConvertASTimezoneToVcalExt(etree.XSLTExtension):
    def execute(self, context, self_node, input_node, output_parent):
        # input_node is ApplicationData (context node); find Timezone child
        tz_node = xml2util.FindChildNode(input_node, "Timezone")
        s = xml2util.GetNodeValue(tz_node)
        if not s:
            return
        dcas = base64.b64decode(s)
        astd = ASTimezoneData()
        astd.UnpackFromAirsync(dcas)
        astd.dump()

        # StartTime is a sibling of Timezone, i.e. child of input_node
        sdate = FindASDateElementContent(input_node, "StartTime")

        if sdate is None:
            year = datetime.datetime.now().year
        else:
            year = int(sdate[0:4])

        # ToVcalTZ uses etree.SubElement — use temp element to avoid proxy issues
        tmp = etree.Element("_tmp")
        astd.ToVcalTZ(tmp, year)
        for child in list(tmp):
            output_parent.append(child)
        CUR_TZ["current"] = astd.tzcurrent

###############################################################################
# _ExtractTZData (Cat.A)
#
# Extract the timezone data from a vcal node block and populate our internal
# timezone database.

def _ExtractTZData(context):
    tznode = context.context_node
    timezone = tzutils.tzone.TZInfoFromVcal(tznode)
    TZDB[timezone.name] = timezone
    astd = ASTimezoneData()
    astd.FromVcalTZ(timezone)
    astd.dump()
    return base64.b64encode(astd.PackToAirsync()).decode()

###############################################################################
# ConvertToUTC
#
# Convert a provided local date to UTC taking into account daylight-savings

def ConvertToUTC(date,tzid):

    if tzid in TZDB:

        tz = TZDB[tzid]
        time = date.replace(tzinfo=tz)
        utc_date = time.astimezone(tzutils.tzone.utc)
    else:
        utc_date = date

    return utc_date

###############################################################################
# ConvertToLocal
#
# Convert a provided UTC date to local time, taking into account daylight
# savings. The arg list is different here as we take an actual timezone
# as an argument, not an index (we maintain no list in the reverse direction
# as every timezone on the AS side could, in fact, be different. If the
# supplied timezone is None - the returned time is unchanged

def ConvertToLocal(date,tz):

    if tz!=None:
        time = date.replace(tzinfo=tzutils.tzone.utc)
        local_date = time.astimezone(tz)
    else:
        local_date = date

    return local_date


###############################################################################
# ConvertDateNodeToUTC
#
# Takes a node containing a <Content> and a <Timezone>. Assumes the <Content>
# is a date. If <TimezoneID> is specified, then will return a UTC representation
# of the string providing the TimezoneID is in the timezone database. If no
# TimezoneID is provided, will assume UTC. Also, if date ends with 'Z', will
# assume UTC from read. Can return None if datetime not present

def ConvertDateNodeToUTC(node):
    date = None
    tdate = None
    udate = None
    ctnode = xml2util.FindChildNode(node,"Content")
    if ctnode != None:
        tdate = xml2util.GetNodeValue(ctnode).upper()
        if tdate != "":
            date = tzutils.TextToDate(tdate)
            udate = date
            if date.tzname() != "UTC":
                tzn=xml2util.FindChildNode(node,"TimezoneID")
                if tzn!=None:
                    udate = ConvertToUTC(date,xml2util.GetNodeValue(tzn))
    else:
        raise ValueError("Bad date content")
    return date,udate

###############################################################################
# register_xpath_functions
#
# Register Cat.A timezone functions via lxml FunctionNamespace

def register_xpath_functions():
    ns = etree.FunctionNamespace("http://synce.org/tz")
    ns.prefix = "tz"
    ns["ExtractTZData"] = _ExtractTZData

###############################################################################
# get_extension_elements
#
# Returns Cat.B extension element classes (populated in Fase 2b)

def get_extension_elements():
    return {
        ("http://synce.org/tz", "ConvertASTimezoneToVcal"): _ConvertASTimezoneToVcalExt(),
    }
