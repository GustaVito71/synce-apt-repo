###############################################################################
# CONVERTERS.py
#
# Converter functions that use the low level wbxml codec to convert between
# lxml Element structures and wbxml strings - and vice versa.
#
# Dr J A Gow 27/1/2008
# Migrated from libxml2 to lxml.etree (Fase C)
#
###############################################################################

from . import dtd
from lxml import etree
from . import codec
import io
import logging

logger = logging.getLogger("engine.wbxml")

###############################################################################
# _processNode
#
# INTERNAL
#
# Recursively traverse an lxml Element tree and encode it to WBXML.
#
###############################################################################

def _processNode(node, encoder):

    logger.debug("processNode")

    if not isinstance(node.tag, str):
        return  # skip comments, PIs, etc.

    logger.debug("content flag:")

    # Extract namespace URI and local name
    if node.tag.startswith('{'):
        ns = node.tag.split('}', 1)[0][1:]
        local = node.tag.split('}', 1)[1]
    else:
        ns = None
        local = node.tag

    tag = (ns, local)

    nocontent = (len(node) == 0 and not node.text)

    logger.debug("TAG %s", tag)
    encoder.StartTag(tag, False, nocontent)

    if node.text:
        encoder.Content(node.text)

    for child in node:
        _processNode(child, encoder)
        if child.tail:
            encoder.Content(child.tail)

    if not nocontent:
        encoder.EndTag()


###############################################################################
# WBXMLToXML
#
# EXPORTED
#
# Taking a WBXML string as an argument, this function produces an lxml
# Element tree corresponding to it.
#
###############################################################################

def WBXMLToXML(wbxml):

    # if we have no input, return an empty element
    if wbxml is None or wbxml == '' or wbxml == b'':
        return etree.Element("empty")

    wbxfile = io.StringIO(wbxml) if isinstance(wbxml, str) else io.BytesIO(wbxml)

    decoder = codec.WBXMLDecoder(wbxfile, dtd.AirsyncDTD)

    root = None
    curTag = None

    while True:

        e = decoder.GetElement()

        if not e:
            break

        if e[codec.EN_TYPE] == codec.EN_TYPE_STARTTAG:

            ns, name = e[codec.EN_TAG]
            tag = "{%s}%s" % (ns, name) if ns else name

            if curTag is None:
                curTag = etree.Element(tag)
                root = curTag
            else:
                curTag = etree.SubElement(curTag, tag)

            if e[codec.EN_FLAGS] & 2:
                logger.debug("must get attrs")

            if not (e[codec.EN_FLAGS] & 1):
                # No content: pop back to parent immediately
                parent = curTag.getparent()
                curTag = parent

        elif e[codec.EN_TYPE] == codec.EN_TYPE_ENDTAG:
            if curTag is not None:
                parent = curTag.getparent()
                curTag = parent
            else:
                logger.debug("error: no parent")

        elif e[codec.EN_TYPE] == codec.EN_TYPE_CONTENT:
            if curTag is not None:
                if len(curTag) == 0:
                    curTag.text = (curTag.text or '') + e[codec.EN_CONTENT]
                else:
                    last_child = curTag[-1]
                    last_child.tail = (last_child.tail or '') + e[codec.EN_CONTENT]
            else:
                logger.debug("error: no node")

    wbxfile.close()

    return root


###############################################################################
# XMLToWBXML
#
# EXPORTED
#
# Going from an lxml Element (or ElementTree), this function returns a WBXML
# string.
#
###############################################################################

def XMLToWBXML(doc):

    # Accept either an ElementTree or a bare Element
    if isinstance(doc, etree._ElementTree):
        root = doc.getroot()
    else:
        root = doc

    wbxml = io.StringIO()

    logger.debug("get encoder")
    encoder = codec.WBXMLEncoder(wbxml, dtd.AirsyncDTD)

    logger.debug("write header")
    encoder.StartWBXML()
    logger.debug("enter processNode")
    _processNode(root, encoder)

    s = wbxml.getvalue()
    wbxml.close()
    return s
