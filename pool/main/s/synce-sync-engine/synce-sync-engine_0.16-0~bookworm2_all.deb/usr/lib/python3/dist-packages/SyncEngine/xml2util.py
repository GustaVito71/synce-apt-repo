# -*- coding: utf-8 -*-
############################################################################
# XML2UTILS.py
#
# Common XML handy functions used across modules
# Migrated from libxml2/libxslt to lxml.etree (Fase C)
#
# Dr J A Gow 15/4/2007
#
############################################################################

from lxml import etree


def _local_name(tag):
    """Strip namespace from Clark notation {ns}name."""
    if tag and tag.startswith('{'):
        return tag.split('}', 1)[1]
    return tag


### lxml utility functions ###

def FindChildNode(node, name):
    for child in node:
        if isinstance(child.tag, str) and _local_name(child.tag) == name:
            return child
    return None

def _collect_text(node):
    """Recursively collect text from a node (works for _ReadOnlyElementProxy too)."""
    parts = [node.text or ""]
    for child in node:
        parts.append(_collect_text(child))
        parts.append(child.tail or "")
    return "".join(parts)


def GetNodeValue(node):
    if node is None:
        return ""
    try:
        return "".join(node.itertext()).strip()
    except AttributeError:
        # _ReadOnlyElementProxy (XSLT extension input_node) has no itertext()
        return _collect_text(node).strip()

def GetNodeAttr(node, attr):
    val = node.get(attr)
    return val.strip() if val is not None else None

def GetNodeOnLevel(parent, level):
    while level > 0:
        children = [c for c in parent if isinstance(c.tag, str)]
        if children:
            parent = children[0]
            level -= 1
            if level == 0:
                return parent
        else:
            return None
