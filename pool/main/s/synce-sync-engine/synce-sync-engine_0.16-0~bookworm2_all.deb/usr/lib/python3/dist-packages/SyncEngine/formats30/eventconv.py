# -*- coding: utf-8 -*-
############################################################################
# EVENTCONV.py
#
# Dr J A Gow 10/11/2007
#
# XSLT extensions used by events only. Contains code split off from the old
# 'conversions' module to keep things a little clearer
#
############################################################################

from lxml import etree
import base64
from time import gmtime, strftime
from . import tzutils
from . import tzdatabase
import SyncEngine.xml2util as xml2util
from . import dateutil
from . import commonconv
import datetime

DATE_FORMAT_SHORT         = '%Y%m%d'
DATE_FORMAT_EVENT         = '%Y%m%dT%H%M%SZ'

###############################################################################
# VcalSplitByDay
#
# Utility function

def VcalSplitByDay(vcal_byday):
    return (vcal_byday[:-2], vcal_byday[-2:])


###############################################################################
# _TimeTransparencyToAirsync (Cat.A)

def _TimeTransparencyToAirsync(context):
    if xml2util.GetNodeValue(context.context_node) == "TRANSPARENT":
        return "0"
    else:
        return "2"  # 'Busy' is our default value

###############################################################################
# _TimeTransparencyFromAirsync (Cat.A)

def _TimeTransparencyFromAirsync(context):
    if xml2util.GetNodeValue(context.context_node) == "0":
        return "TRANSPARENT"
    else:
        return "OPAQUE"  # 'Busy' is our default value

###############################################################################
# _AllDayEventToAirsync (Cat.A)
#
# We look for an all-day event by examining the <DateStarted> element. This
# will have a value of DATE, rather than DATE-TIME if an all day event

def _AllDayEventToAirsync(context):
    src_node = context.context_node
    datetext = xml2util.GetNodeValue(xml2util.FindChildNode(src_node, "Content"))
    if datetext.find("T") >= 0:
        return "0"
    else:
        return "1"

###############################################################################
# _AttendeeToAirsyncExt (Cat.B)

class _AttendeeToAirsyncExt(etree.XSLTExtension):
    def execute(self, context, self_node, input_node, output_parent):
        email = xml2util.GetNodeValue(xml2util.FindChildNode(input_node, "Content"))[7:]
        name = xml2util.GetNodeValue(xml2util.FindChildNode(input_node, "CommonName"))
        if name != "":
            name_el = etree.Element("Name")
            name_el.text = name
            output_parent.append(name_el)
        email_el = etree.Element("Email")
        email_el.text = email
        output_parent.append(email_el)

###############################################################################
# _AttendeeFromAirsyncExt (Cat.B)

class _AttendeeFromAirsyncExt(etree.XSLTExtension):
    def execute(self, context, self_node, input_node, output_parent):
        email = xml2util.GetNodeValue(xml2util.FindChildNode(input_node, "Email"))
        name = xml2util.GetNodeValue(xml2util.FindChildNode(input_node, "Name"))
        if email != "":
            content_el = etree.Element("Content")
            content_el.text = "MAILTO:%s" % email
            output_parent.append(content_el)
        cn_el = etree.Element("CommonName")
        cn_el.text = name
        output_parent.append(cn_el)

###############################################################################
# _ExceptionDateTimeToAirsyncExt (Cat.B)

class _ExceptionDateTimeToAirsyncExt(etree.XSLTExtension):
    def execute(self, context, self_node, input_node, output_parent):
        exclusion_date = dateutil.XMLDateTimeToDate(input_node, tzdatabase.tzdb)
        exclusion_value = xml2util.GetNodeAttr(input_node, "Value")

        if exclusion_value is not None:
            if exclusion_value.lower() != "date":
                raise ValueError("Exclusions with values other than 'DATE' are not supported")

        exclusion_date = exclusion_date.astimezone(tzutils.tzone.utc)
        del_el = etree.Element("Deleted")
        del_el.text = "1"
        output_parent.append(del_el)
        exc_el = etree.Element("ExceptionStartTime")
        exc_el.text = exclusion_date.strftime(DATE_FORMAT_EVENT)
        output_parent.append(exc_el)

###############################################################################
# _ExceptionDateTimeFromAirsyncExt (Cat.B)

class _ExceptionDateTimeFromAirsyncExt(etree.XSLTExtension):
    def execute(self, context, self_node, input_node, output_parent):
        exception_deleted = xml2util.GetNodeValue(xml2util.FindChildNode(input_node, "Deleted"))
        exception_date = xml2util.GetNodeValue(xml2util.FindChildNode(input_node, "ExceptionStartTime"))

        if exception_deleted != "1":
            raise ValueError("Opensync does not support exceptions for modified occurrences")

        date = dateutil.TextToDate(exception_date)
        curtz = tzdatabase.tzdb.GetCurrentTimezone()
        if curtz is not None:
            date = date.astimezone(curtz)
            output_parent.attrib["TimezoneID"] = curtz.name

        output_parent.attrib["Value"] = "DATE"
        content_el = etree.Element("Content")
        content_el.text = date.strftime(DATE_FORMAT_SHORT)
        output_parent.append(content_el)


###############################################################################
# register_xpath_functions
#
# Register Cat.A event converter functions via lxml FunctionNamespace

def register_xpath_functions():
    ns = etree.FunctionNamespace("http://synce.org/event")
    ns.prefix = "event"
    ns["TimeTransparencyToAirsync"]   = _TimeTransparencyToAirsync
    ns["TimeTransparencyFromAirsync"] = _TimeTransparencyFromAirsync
    ns["AllDayEventToAirsync"]        = _AllDayEventToAirsync

###############################################################################
# get_extension_elements
#
# Returns Cat.B extension element classes (populated in Fase 2b)

def get_extension_elements():
    return {
        ("http://synce.org/event", "AttendeeToAirsync"):           _AttendeeToAirsyncExt(),
        ("http://synce.org/event", "AttendeeFromAirsync"):         _AttendeeFromAirsyncExt(),
        ("http://synce.org/event", "ExceptionDateTimeToAirsync"):  _ExceptionDateTimeToAirsyncExt(),
        ("http://synce.org/event", "ExceptionDateTimeFromAirsync"):_ExceptionDateTimeFromAirsyncExt(),
    }
