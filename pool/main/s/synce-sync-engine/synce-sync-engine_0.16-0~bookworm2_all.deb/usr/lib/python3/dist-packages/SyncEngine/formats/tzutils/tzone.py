# -*- coding: utf-8 -*-

############################################################################
# DATEUTIL.py
#
# Utilities for date processing
#
# Dr J A Gow 10/4/2007
#
############################################################################

import datetime
from . import recurrence
from . import dateutil


def _local_name(tag):
    if tag and tag.startswith('{'):
        return tag.split('}', 1)[1]
    return tag

#
# UTC timezone class
#
# Really does nothing but allows us to convert between local and UTC

class UtcTZ(datetime.tzinfo):

    def utcoffset(self, dt):
        return datetime.timedelta(0)

    def tzname(self, dt):
        return "UTC"

    def dst(self, dt):
        return datetime.timedelta(0)

# handy instance

utc = UtcTZ()

#
# VcalTZ class
#
# Derived timezone class that reflects a vcal timezone

class VcalTZ(datetime.tzinfo):
    
    #
    # __init__
    #
    # required by the definition for a tzinfo
    
    def __init__(self):
        
        self.name = None
        self.loc  = None
        
        self.dstname = ""
        self.dstoffset = datetime.timedelta(seconds=0)
        self.dstRecurrence = recurrence.RecurrentEvent()
        
        self.stdname = ""
        self.stdoffset = datetime.timedelta(seconds=0)
        self.stdRecurrence = recurrence.RecurrentEvent()
        
    #
    # utcoffset
    #
    # return the utc offset including dst
        
        
    def utcoffset(self,dt):
        return self.stdoffset + self.dst(dt)
        
    #
    # dst
    #
    # return dst
        
    def dst(self,dt):
        dlt = dt.replace(tzinfo=None)
        
        # make sure we have sufficient DST and STD recurrences
        # to take us to the current date
        
        self.dstRecurrence.ProcessIteration(dlt)
        self.stdRecurrence.ProcessIteration(dlt)
            
        # Now get the deltas between us and the DST events
        
        deltaDST = datetime.timedelta.max
        deltaSTD = datetime.timedelta.max
        
        # If no valid dstRecurrence, delta is zero
        
        for m in reversed(self.dstRecurrence.ilist):
            if m > dlt:
                continue
            deltaDST = dlt - m
            break
        
        # if no valid stdRecurrence, delta is zero 
         
        for m in reversed(self.stdRecurrence.ilist):
            if m > dlt:
                continue
            deltaSTD = dlt - m
            break
                    
        if deltaDST < deltaSTD:
            # we are in DST
            return self.dstoffset
        else:
            # we are in STD
            return datetime.timedelta(0)

    #
    # tzname
    #
    
    def tzname(self,dt):
        return self.name

#
# TZInfoFromVcal
#
# Function providing vcal support 
    
def TZInfoFromVcal(tznode):

    tz = VcalTZ()

    for child in tznode:
        if not isinstance(child.tag, str):
            continue
        name = _local_name(child.tag)

        if name == "TimezoneID":
            tz.name = (child.text or "").strip()
        if name == "Location":
            tz.loc = (child.text or "").strip()
        if name == "Standard":
            for cstd in child:
                if not isinstance(cstd.tag, str):
                    continue
                cname = _local_name(cstd.tag)
                if cname == "TimezoneName":
                    tz.stdname = (cstd.text or "").strip()
                if cname == "DateStarted":
                    tz.stdRecurrence.SetStartDateFromText((cstd.text or "").strip())
                if cname == "RecurrenceRule":
                    for rule in cstd:
                        if isinstance(rule.tag, str) and _local_name(rule.tag) == "Rule":
                            tz.stdRecurrence.AppendStringRule((rule.text or "").strip())
                if cname == "TZOffsetTo":
                    tz.stdoffset = dateutil.OffsetToDelta((cstd.text or "").strip())

        if name == "DaylightSavings":
            dso1 = datetime.timedelta(0)
            dso2 = datetime.timedelta(0)
            for cstd in child:
                if not isinstance(cstd.tag, str):
                    continue
                cname = _local_name(cstd.tag)
                if cname == "TimezoneName":
                    tz.dstname = (cstd.text or "").strip()
                if cname == "DateStarted":
                    tz.dstRecurrence.SetStartDateFromText((cstd.text or "").strip())
                if cname == "RecurrenceRule":
                    for rule in cstd:
                        if isinstance(rule.tag, str) and _local_name(rule.tag) == "Rule":
                            tz.dstRecurrence.AppendStringRule((rule.text or "").strip())
                if cname == "TZOffsetTo":
                    dso1 = dateutil.OffsetToDelta((cstd.text or "").strip())
                if cname == "TZOffsetFrom":
                    dso2 = dateutil.OffsetToDelta((cstd.text or "").strip())
            tz.dstoffset = dso1 - dso2

    return tz
