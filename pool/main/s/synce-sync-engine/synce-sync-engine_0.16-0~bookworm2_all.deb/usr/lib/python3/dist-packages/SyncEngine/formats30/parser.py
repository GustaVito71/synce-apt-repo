# -*- coding: utf-8 -*-
############################################################################
#    Copyright (C) 2006  Ole André Vadla Ravnås <oleavr@gmail.com>       #
#                                                                          #
#    This program is free software; you can redistribute it and#or modify  #
#    it under the terms of the GNU General Public License as published by  #
#    the Free Software Foundation; either version 2 of the License, or     #
#    (at your option) any later version.                                   #
#                                                                          #
#    This program is distributed in the hope that it will be useful,       #
#    but WITHOUT ANY WARRANTY; without even the implied warranty of        #
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         #
#    GNU General Public License for more details.                          #
#                                                                          #
#    You should have received a copy of the GNU General Public License     #
#    along with this program; if not, write to the                         #
#    Free Software Foundation, Inc.,                                       #
#    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             #
############################################################################

from lxml import etree
import os
from SyncEngine.constants import *
import logging
from . import commonconv
from . import eventconv
from . import contactconv
from . import taskconv
from . import tzdatabase


class Parser:

    FORMATS_PATH = os.path.dirname(os.path.abspath(__file__))

    def __init__(self):
        self.logger = logging.getLogger("engine.formats.parser.Parser")

        # Register Cat.A XPath extension functions (global, once)
        commonconv.register_xpath_functions()
        eventconv.register_xpath_functions()
        contactconv.register_xpath_functions()
        taskconv.register_xpath_functions()

        # Collect Cat.B XSLTExtension elements
        extensions = {}
        extensions.update(commonconv.get_extension_elements())
        extensions.update(eventconv.get_extension_elements())
        extensions.update(contactconv.get_extension_elements())
        extensions.update(taskconv.get_extension_elements())

        def _load(xsl_file):
            return etree.XSLT(etree.parse(xsl_file), extensions=extensions)

        fp = self.FORMATS_PATH
        self.STYLESHEETS = {
            SYNC_ITEM_CONTACTS: {
                DIR_TO_AIRSYNC:   _load(fp + "/contact-to-airsync.xsl"),
                DIR_FROM_AIRSYNC: _load(fp + "/contact-from-airsync.xsl"),
            },
            SYNC_ITEM_CALENDAR: {
                DIR_TO_AIRSYNC:   _load(fp + "/event-to-airsync.xsl"),
                DIR_FROM_AIRSYNC: _load(fp + "/event-from-airsync.xsl"),
            },
            SYNC_ITEM_TASKS: {
                DIR_TO_AIRSYNC:   _load(fp + "/task-to-airsync.xsl"),
                DIR_FROM_AIRSYNC: _load(fp + "/task-from-airsync.xsl"),
            },
        }

    def convert(self, src_doc, item_type, direction):
        if item_type not in self.STYLESHEETS:
            raise ValueError("Unsupported item type %d" % item_type)
        if direction not in self.STYLESHEETS[item_type]:
            raise ValueError("Unsupported direction %d" % direction)

        tzdatabase.tzdb.Flush()
        stylesheet = self.STYLESHEETS[item_type][direction]
        return stylesheet(src_doc)


parser = Parser()
