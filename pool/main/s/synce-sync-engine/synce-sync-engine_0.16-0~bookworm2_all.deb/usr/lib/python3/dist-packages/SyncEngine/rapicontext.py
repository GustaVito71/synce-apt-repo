# -*- coding: utf-8 -*-
###############################################################################
# RAPICONTEXT.py
#
# Converted from the original rapiutil.py to provide an object with methods
# for each RAPI/ProcessConfig request
#
# Original rapiutil: (C) 2006  Ole André Vadla Ravnås <oleavr@gmail.com>
#
# Dr J A Gow 28/11/2007
#
###############################################################################

from lxml import etree
from . import xml2util
from . import characteristics
import logging
import pyrapi2

logger = logging.getLogger("engine.rapicontext")

QUERY_TYPE_GET      = 0
QUERY_TYPE_SET      = 1
QUERY_TYPE_REMOVE   = 2

class RapiContext(pyrapi2.RAPISession):

    def __init__(self,device,loglevel):
        pyrapi2.RAPISession.__init__(self,device,loglevel)

    def GetConfig(self,path,leaf,recursive=False):
        return self._ConfigQuery(QUERY_TYPE_GET, path, leaf, recursive)

    def SetConfig(self,path,ctic):
        return self._ConfigQuery(QUERY_TYPE_SET, path, None, ctic=ctic)

    def RemoveConfig(self,path,leaf):
        return self._ConfigQuery(QUERY_TYPE_REMOVE, path, leaf)

    def _ConfigQuery(self, query_type, path, leaf=None, recursive=False, ctic=None):

        doc_node = etree.Element("wap-provisioningdoc")
        parent = doc_node

        if path is not None:

            tokens = path.split(".")

            for token in tokens:
                node = etree.SubElement(parent, "characteristic")
                node.set("type", token)
                parent = node
        else:
            tokens = []

        if query_type == QUERY_TYPE_GET:

            node = etree.Element("characteristic-query")
            if not recursive:
                node.set("recursive", "false")
            node.set("type", leaf)

        elif query_type == QUERY_TYPE_REMOVE:

            node = etree.Element("nocharacteristic")
            node.set("type", leaf)

        elif query_type == QUERY_TYPE_SET:
            node = characteristics.characteristic_tree_to_xml(ctic, None)

        parent.append(node)

        logger.debug("_config_query: CeProcessConfig request is \n%s",
                     etree.tostring(doc_node, encoding="unicode", pretty_print=True))

        reply = self.process_config(etree.tostring(doc_node, encoding="unicode"), 1)
        reply_doc = etree.fromstring(reply) if isinstance(reply, bytes) else etree.fromstring(reply.encode())

        logger.debug("_config_query: CeProcessConfig response is \n%s",
                     etree.tostring(reply_doc, encoding="unicode", pretty_print=True))

        # reply_doc is already the root element; subtract one level vs the old libxml2 doc object
        reply_node = xml2util.GetNodeOnLevel(reply_doc, 1 + len(tokens))

        if query_type != QUERY_TYPE_SET:
            return characteristics.characteristic_tree_from_xml(reply_node)
        else:
            return None
