# -*- coding: utf-8 -*-
############################################################################
# CONTACTCONV.py
#
# Dr J A Gow 10/11/2007
#
# XSLT extensions used by contacts only. Contains code split off from the old
# 'conversions' module to keep things a little clearer
#
############################################################################

from lxml import etree
import SyncEngine.xml2util as xml2util

###############################################################################
# _AnniversaryToAirsync (Cat.A)
#
# This is a straightforward date conversion with no timezone

def _AnniversaryToAirsync(context):
    return xml2util.GetNodeValue(context.context_node) + "T00:00:00.000Z"

###############################################################################
# _AnniversaryFromAirsync (Cat.A)
#
# This is a straightforward date conversion with no timezone

def _AnniversaryFromAirsync(context):
    return xml2util.GetNodeValue(context.context_node).split("T")[0]

###############################################################################
# _BirthdayToAirsync (Cat.A)
#
# This is a straightforward date conversion with no timezone

def _BirthdayToAirsync(context):
    s = xml2util.GetNodeValue(context.context_node)
    return "%s-%s-%sT00:00:00.000Z" % (s[0:4], s[4:6], s[6:8])

###############################################################################
# _BirthdayFromAirsync (Cat.A)
#
# This is a straightforward date conversion with no timezone

def _BirthdayFromAirsync(context):
    return xml2util.GetNodeValue(context.context_node).split("T")[0].replace("-", "")


###############################################################################
# register_xpath_functions
#
# Register contact converter functions via lxml FunctionNamespace

def register_xpath_functions():
    ns = etree.FunctionNamespace("http://synce.org/contact")
    ns.prefix = "contact"
    ns["AnniversaryToAirsync"]   = _AnniversaryToAirsync
    ns["AnniversaryFromAirsync"] = _AnniversaryFromAirsync
    ns["BirthdayToAirsync"]      = _BirthdayToAirsync
    ns["BirthdayFromAirsync"]    = _BirthdayFromAirsync

###############################################################################
# get_extension_elements
#
# Returns Cat.B extension element classes (none for contacts)

def get_extension_elements():
    return {}
