# -*- coding: utf-8 -*-
# vim: set tabstop=4 shiftwidth=4 expandtab:
############################################################################
#    Copyright (C) 2006  Ole André Vadla Ravnås <oleavr@gmail.com>         #
#    MODIFIED: 17/2/2007 Dr J A Gow: Task support added                    #
#                                                                          #
#    This program is free software; you can redistribute it and#or modify  #
#    it under the terms of the GNU General Public License as published by  #
#    the Free Software Foundation; either version 2 of the License, or     #
#    (at your option) any later version.                                   #
#                                                                          #
#    This program is distributed in the hope that it will be useful,       #
#    but WITHOUT ANY WARRANTY; without even the implied warranty of        #
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         #
#    GNU General Public License for more details.                          #
#                                                                          #
#    You should have received a copy of the GNU General Public License     #
#    along with this program; if not, write to the                         #
#    Free Software Foundation, Inc.,                                       #
#    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             #
############################################################################

from lxml import etree
import pyrtfcomp
import base64
import re
from . import tzconv
from time import gmtime, strftime
from . import tzutils
import SyncEngine.xml2util as xml2util

### conversion constants ###

RTFHDR = b"\\ansi \\deff0{\\fonttbl{\\f0\\fnil\\fcharset0\\fprq0 Tahoma;}{\\f1\\froman\\fcharset2\\fprq2 "
RTFHDR += b"Symbol;}{\\f2\\fswiss\\fcharset204\\fprq2  ;}}{\\colortbl;\\red0\\green0\\blue0;\\red128\\green128"
RTFHDR += b"\\blue128;\\red192\\green192\\blue192;\\red255\\green255\\blue255;\\red255\\green0\\blue0;\\red0"
RTFHDR += b"\\green255\\blue0;\\red0\\green0\\blue255;\\red0\\green255\\blue255;\\red255\\green0\\blue255;"
RTFHDR += b"\\red255\\green255\\blue0;\\red128\\green0\\blue0;\\red0\\green128\\blue0;\\red0\\green0"
RTFHDR += b"\\blue128;\\red0\\green128\\blue128;\\red128\\green0\\blue128;\\red128\\green128\\blue0;}\x0a\x0d"
RTFHDR += b"\\f0 \\fs16 "

DATE_FORMAT_NORMAL        = '%Y%m%dT%H%M%SZ'
DATE_FORMAT_EVENT         = '%Y%m%dT%H%M%SZ'
DATE_FORMAT_EVLOCAL       = '%Y%m%dT%H%M%S'
DATE_FORMAT_TASK          = '%Y-%m-%dT%H:%M:%S.000Z'
DATE_FORMAT_TASKLOCAL     = '%Y-%m-%dT%H:%M:%S.000'
DATE_FORMAT_VCALTASK      = '%Y%m%dT%H%M%SZ'
DATE_FORMAT_VCALTASKLOCAL = '%Y%m%dT%H%M%S'
DATE_FORMAT_SHORT         = '%Y%m%d'

MINUTES_PER_HOUR    = 60
MINUTES_PER_DAY     = MINUTES_PER_HOUR * 24

vcal_days_to_airsync_days_map = { "SU" : 1,
                                  "MO" : 2,
                                  "TU" : 4,
                                  "WE" : 8,
                                  "TH" : 16,
                                  "FR" : 32,
                                  "SA" : 64 }

airsync_days_to_vcal_days_map = {  1   : "SU",
                                   2   : "MO",
                                   4   : "TU",
                                   8   : "WE",
                                   16  : "TH",
                                   32  : "FR",
                                   64  : "SA" }


### Conversion Utility functions ###

def vcal_days_to_airsync_days(vcal_days):
    airsync_days = 0
    for vcal_day in vcal_days.split(","):
        airsync_days = airsync_days | vcal_days_to_airsync_days_map[vcal_day.upper()]
    return airsync_days

def airsync_days_to_vcal_days(airsync_days):
    vcal_days = []
    for i in range(0,8):
        mask = (1 << i)
        if mask & int(airsync_days):
            vcal_days.append(airsync_days_to_vcal_days_map[mask])
    return ",".join(vcal_days)

def vcal_split_byday(vcal_byday):
    return (vcal_byday[:-2], vcal_byday[-2:])

def generate_vcal_byday(airsync_week, airsync_day):
    week = int(airsync_week)
    if week == 5:
        week = -1
    return "%d%s" % (week, airsync_days_to_vcal_days_map[int(airsync_day)])

### Cat.A conversion functions ###

def _contact_has_type(context, type_string):
    curnode = context.context_node
    for child in curnode:
        if not isinstance(child.tag, str):
            continue
        if xml2util._local_name(child.tag) != "Type":
            continue
        if xml2util.GetNodeValue(child).upper() == type_string:
            return True
    return False

def _contact_position(context):
    curnode = context.context_node
    # Extract the types of the current node
    types = []
    for child in curnode:
        if isinstance(child.tag, str) and xml2util._local_name(child.tag) == "Type":
            types.append(xml2util.GetNodeValue(child).upper())
    types.sort()
    curname = xml2util._local_name(curnode.tag)
    position = 1
    # Walk preceding siblings
    prevnode = curnode.getprevious()
    while prevnode is not None:
        if isinstance(prevnode.tag, str) and xml2util._local_name(prevnode.tag) == curname:
            prev_types = []
            for child in prevnode:
                if isinstance(child.tag, str) and xml2util._local_name(child.tag) == "Type":
                    prev_types.append(xml2util.GetNodeValue(child).upper())
            prev_types.sort()
            if prev_types == types:
                position += 1
        prevnode = prevnode.getprevious()
    return position

def _event_reminder_to_airsync(context):
    src_node = context.context_node
    content_node = xml2util.FindChildNode(src_node, "Content")
    value_node = xml2util.FindChildNode(src_node, "Value")
    related_node = xml2util.FindChildNode(src_node, "Related")
    if value_node is None or xml2util.GetNodeValue(value_node).lower() != "duration":
        return ""
    if related_node is not None and xml2util.GetNodeValue(related_node).lower() != "start":
        return ""
    s = xml2util.GetNodeValue(content_node)
    s = s.lstrip("-PT")
    s = s.upper()
    days = 0
    hours = 0
    minutes = 0
    if s.rfind("D") != -1:
        days = int(s[:s.rfind("D")])
        s = s[s.rfind("D")+1:]
    if s.rfind("H") != -1:
        hours = int(s[:s.rfind("H")])
        s = s[s.rfind("H")+1:]
    if s.rfind("M") != -1:
        minutes = int(s[:s.rfind("M")])
        s = s[s.rfind("M")+1:]
    return str(days * MINUTES_PER_DAY + hours * MINUTES_PER_HOUR + minutes)

def _event_reminder_from_airsync(context):
    s = int(xml2util.GetNodeValue(context.context_node))
    if s % MINUTES_PER_DAY == 0:
        return "-P%iD" % (s // MINUTES_PER_DAY)
    elif s % MINUTES_PER_HOUR == 0:
        return "-PT%iH" % (s // MINUTES_PER_HOUR)
    else:
        return "-PT%iM" % s

def _event_time_to_airsync(context):
    return tzconv.ConvertDateNodeToUTC(context.context_node)[1].strftime(DATE_FORMAT_EVENT)

def _event_datetime_from_airsync(context, nodes=None):
    if nodes is not None and len(nodes) > 0:
        value = xml2util.GetNodeValue(nodes[0])
    else:
        value = xml2util.GetNodeValue(context.context_node)
    return tzutils.TextToDate(value).strftime(DATE_FORMAT_EVENT)

def _event_datetime_short_from_airsync(context, nodes=None):
    if nodes is not None and len(nodes) > 0:
        value = xml2util.GetNodeValue(nodes[0])
    else:
        value = xml2util.GetNodeValue(context.context_node)
    return tzutils.TextToDate(value).strftime(DATE_FORMAT_SHORT)

def _event_dtstamp_from_now(context):
    return strftime("%Y%m%dT%H%M%SZ", gmtime())

def _event_alldayevent_to_airsync(context):
    if xml2util.GetNodeValue(context.context_node).find("T") >= 0:
        return "0"
    else:
        return "1"

def _curtz_name(context):
    """Return current timezone name, or empty string if no timezone loaded."""
    tz = tzconv.curtz()
    return tz.name if tz is not None else ""

### Cat.B conversion functions (Fase 2b) ###

class _EventStarttimeFromAirsyncExt(etree.XSLTExtension):
    def execute(self, context, self_node, input_node, output_parent):
        _event_starttime_from_airsync(input_node, output_parent)

def _event_starttime_from_airsync(input_node, output_parent):
    allday_node = xml2util.FindChildNode(input_node.getparent(), "AllDayEvent")
    asdate = tzutils.TextToDate(xml2util.GetNodeValue(input_node))
    is_allday = allday_node is not None and xml2util.GetNodeValue(allday_node) != "0"

    if tzconv.curtz() is not None:
        asdate = tzconv.ConvertToLocal(asdate, tzconv.curtz())
        result = asdate.strftime(DATE_FORMAT_EVLOCAL)
        tz_el = etree.Element("TimezoneID")
        tz_el.text = tzconv.curtz().name
        output_parent.append(tz_el)
    else:
        result = asdate.strftime(DATE_FORMAT_EVENT)

    if is_allday:
        result = result[0:8]

    content = etree.Element("Content")
    content.text = result
    output_parent.append(content)

class _EventEndtimeFromAirsyncExt(etree.XSLTExtension):
    def execute(self, context, self_node, input_node, output_parent):
        _event_endtime_from_airsync(input_node, output_parent)

def _event_endtime_from_airsync(input_node, output_parent):
    allday_node = xml2util.FindChildNode(input_node.getparent(), "AllDayEvent")
    asdate = tzutils.TextToDate(xml2util.GetNodeValue(input_node))
    is_allday = allday_node is not None and xml2util.GetNodeValue(allday_node) != "0"

    if tzconv.curtz() is not None:
        asdate = tzconv.ConvertToLocal(asdate, tzconv.curtz())
        result = asdate.strftime(DATE_FORMAT_EVLOCAL)
        tz_el = etree.Element("TimezoneID")
        tz_el.text = tzconv.curtz().name
        output_parent.append(tz_el)
    else:
        result = asdate.strftime(DATE_FORMAT_EVENT)

    if is_allday:
        result = result[0:8]

    content = etree.Element("Content")
    content.text = result
    output_parent.append(content)

class _EventRecurrenceToAirsyncExt(etree.XSLTExtension):
    def execute(self, context, self_node, input_node, output_parent):
        tmp = etree.Element("_tmp")
        _event_recurrence_to_airsync(input_node, tmp)
        for child in list(tmp):
            output_parent.append(child)

def _event_recurrence_to_airsync(input_node, output_parent):
    src_node = input_node

    # Extract the rules
    src_rules = {}
    for child in src_node:
        if isinstance(child.tag, str) and xml2util._local_name(child.tag) == "Rule":
            rrule_val = xml2util.GetNodeValue(child)
            sep = rrule_val.index("=")
            key = rrule_val[:sep]
            val = rrule_val[sep+1:]
            src_rules[key.lower()] = val.lower()

    if "interval" in src_rules:
        etree.SubElement(output_parent, "Interval").text = src_rules["interval"]
    if "until" in src_rules:
        etree.SubElement(output_parent, "Until").text = tzutils.TextToDate(src_rules["until"]).strftime(DATE_FORMAT_EVENT)
    if "count" in src_rules:
        etree.SubElement(output_parent, "Occurrences").text = src_rules["count"]

    freq = src_rules.get("freq", "").lower()
    if freq == "daily":
        etree.SubElement(output_parent, "Type").text = "0"
    elif freq == "weekly":
        etree.SubElement(output_parent, "Type").text = "1"
        etree.SubElement(output_parent, "DayOfWeek").text = str(vcal_days_to_airsync_days(src_rules["byday"]))
    elif freq == "monthly":
        if "bymonthday" in src_rules:
            etree.SubElement(output_parent, "Type").text = "2"
            etree.SubElement(output_parent, "DayOfMonth").text = src_rules["bymonthday"]
        elif "byday" in src_rules:
            week, day = vcal_split_byday(src_rules["byday"])
            etree.SubElement(output_parent, "Type").text = "3"
            etree.SubElement(output_parent, "DayOfWeek").text = str(vcal_days_to_airsync_days(day))
            if int(week) >= 0:
                etree.SubElement(output_parent, "WeekOfMonth").text = week
            elif int(week) == -1:
                etree.SubElement(output_parent, "WeekOfMonth").text = "5"
            else:
                raise ValueError("Airsync does not support counting from end of month")
        else:
            raise ValueError("Monthly events must either specify BYMONTHDAY or BYDAY rules")
    elif freq == "yearly":
        if "bymonth" in src_rules:
            if "bymonthday" in src_rules:
                etree.SubElement(output_parent, "Type").text = "5"
                etree.SubElement(output_parent, "MonthOfYear").text = src_rules["bymonth"]
                etree.SubElement(output_parent, "DayOfMonth").text = src_rules["bymonthday"]
            elif "byday" in src_rules:
                week, day = vcal_split_byday(src_rules["byday"])
                etree.SubElement(output_parent, "Type").text = "6"
                etree.SubElement(output_parent, "MonthOfYear").text = src_rules["bymonth"]
                etree.SubElement(output_parent, "DayOfWeek").text = str(vcal_days_to_airsync_days(day))
                if int(week) >= 0:
                    etree.SubElement(output_parent, "WeekOfMonth").text = week
                elif int(week) == -1:
                    etree.SubElement(output_parent, "WeekOfMonth").text = "5"
                else:
                    raise ValueError("Airsync does not support counting from end of month")
            else:
                raise ValueError("Yearly events which are by month must specify BYMONTHDAY or BYDAY rules")
        elif "byyearday" in src_rules:
            raise ValueError("Airsync does not support day-of-year yearly events")
        else:
            start = xml2util.FindChildNode(src_node.getparent(), "DateStarted")
            utcdate = tzconv.ConvertDateNodeToUTC(start)[1]
            etree.SubElement(output_parent, "Type").text = "5"
            etree.SubElement(output_parent, "MonthOfYear").text = str(utcdate.month)
            etree.SubElement(output_parent, "DayOfMonth").text = str(utcdate.day)

class _EventRecurrenceFromAirsyncExt(etree.XSLTExtension):
    def execute(self, context, self_node, input_node, output_parent):
        tmp = etree.Element("_tmp")
        _event_recurrence_from_airsync(input_node, tmp)
        for child in list(tmp):
            output_parent.append(child)

def _event_recurrence_from_airsync(input_node, output_parent):
    src_node = input_node

    interval_node    = xml2util.FindChildNode(src_node, "Interval")
    until_node       = xml2util.FindChildNode(src_node, "Until")
    occurrences_node = xml2util.FindChildNode(src_node, "Occurrences")
    type_node        = xml2util.FindChildNode(src_node, "Type")
    dayofweek_node   = xml2util.FindChildNode(src_node, "DayOfWeek")
    dayofmonth_node  = xml2util.FindChildNode(src_node, "DayOfMonth")
    weekofmonth_node = xml2util.FindChildNode(src_node, "WeekOfMonth")
    monthofyear_node = xml2util.FindChildNode(src_node, "MonthOfYear")

    if interval_node is not None:
        etree.SubElement(output_parent, "Rule").text = "INTERVAL=%s" % xml2util.GetNodeValue(interval_node)
    if until_node is not None:
        etree.SubElement(output_parent, "Rule").text = "UNTIL=%s" % xml2util.GetNodeValue(until_node)
    if occurrences_node is not None:
        etree.SubElement(output_parent, "Rule").text = "COUNT=%s" % xml2util.GetNodeValue(occurrences_node)

    if type_node is not None:
        rtype = int(xml2util.GetNodeValue(type_node))
        if rtype == 0 and dayofweek_node is not None:
            rtype = 1
        if rtype == 0:
            etree.SubElement(output_parent, "Rule").text = "FREQ=DAILY"
        elif rtype == 1:
            etree.SubElement(output_parent, "Rule").text = "FREQ=WEEKLY"
            etree.SubElement(output_parent, "Rule").text = "BYDAY=%s" % airsync_days_to_vcal_days(xml2util.GetNodeValue(dayofweek_node))
        elif rtype == 2:
            etree.SubElement(output_parent, "Rule").text = "FREQ=MONTHLY"
            etree.SubElement(output_parent, "Rule").text = "BYMONTHDAY=%s" % xml2util.GetNodeValue(dayofmonth_node)
        elif rtype == 3:
            etree.SubElement(output_parent, "Rule").text = "FREQ=MONTHLY"
            etree.SubElement(output_parent, "Rule").text = "BYDAY=%s" % generate_vcal_byday(xml2util.GetNodeValue(weekofmonth_node), xml2util.GetNodeValue(dayofweek_node))
        elif rtype == 5:
            etree.SubElement(output_parent, "Rule").text = "FREQ=YEARLY"
            etree.SubElement(output_parent, "Rule").text = "BYMONTH=%s" % xml2util.GetNodeValue(monthofyear_node)
            etree.SubElement(output_parent, "Rule").text = "BYMONTHDAY=%s" % xml2util.GetNodeValue(dayofmonth_node)
        elif rtype == 6:
            etree.SubElement(output_parent, "Rule").text = "FREQ=YEARLY"
            etree.SubElement(output_parent, "Rule").text = "BYMONTH=%s" % xml2util.GetNodeValue(monthofyear_node)
            etree.SubElement(output_parent, "Rule").text = "BYDAY=%s" % generate_vcal_byday(xml2util.GetNodeValue(weekofmonth_node), xml2util.GetNodeValue(dayofweek_node))
        else:
            raise ValueError("Unknown recurrence type %d from Airsync" % rtype)
    else:
        raise ValueError("No recurrence type specified from Airsync")

class _TaskStartDateToAirsyncExt(etree.XSLTExtension):
    def execute(self, context, self_node, input_node, output_parent):
        _task_start_date_to_airsync(input_node, output_parent)

def _task_start_date_to_airsync(input_node, output_parent):
    # StartDate without DueDate is not allowed
    duedate_node = xml2util.FindChildNode(input_node.getparent(), "DateDue")
    if not duedate_node:
        return
    localDate, utcDate = tzconv.ConvertDateNodeToUTC(input_node)
    ns = "http://synce.org/formats/airsync_wm5/tasks"
    sd = etree.Element("{%s}StartDate" % ns)
    sd.text = localDate.strftime(DATE_FORMAT_TASKLOCAL)
    output_parent.append(sd)
    usd = etree.Element("{%s}UtcStartDate" % ns)
    usd.text = utcDate.strftime(DATE_FORMAT_TASK)
    output_parent.append(usd)

class _TaskDueDateToAirsyncExt(etree.XSLTExtension):
    def execute(self, context, self_node, input_node, output_parent):
        _task_due_date_to_airsync(input_node, output_parent)

def _task_due_date_to_airsync(input_node, output_parent):
    localDate, utcDate = tzconv.ConvertDateNodeToUTC(input_node)
    ns = "http://synce.org/formats/airsync_wm5/tasks"
    dd = etree.Element("{%s}DueDate" % ns)
    dd.text = localDate.strftime(DATE_FORMAT_TASKLOCAL)
    output_parent.append(dd)
    udd = etree.Element("{%s}UtcDueDate" % ns)
    udd.text = utcDate.strftime(DATE_FORMAT_TASK)
    output_parent.append(udd)

class _TaskStartDateFromAirsyncExt(etree.XSLTExtension):
    def execute(self, context, self_node, input_node, output_parent):
        _task_start_date_from_airsync(input_node, output_parent)

def _task_start_date_from_airsync(input_node, output_parent):
    asdate = tzutils.TaskTextToDate(xml2util.GetNodeValue(input_node))

    if tzconv.curtz() is not None:
        asdate = tzconv.ConvertToLocal(asdate, tzconv.curtz())
        result = asdate.strftime(DATE_FORMAT_VCALTASKLOCAL)
    else:
        nd = xml2util.FindChildNode(input_node.getparent(), "UtcStartDate")
        if nd is not None:
            result = tzutils.TaskTextToDate(xml2util.GetNodeValue(nd)).strftime(DATE_FORMAT_VCALTASK)
        else:
            result = asdate.strftime(DATE_FORMAT_VCALTASKLOCAL)

    content = etree.Element("Content")
    content.text = result
    output_parent.append(content)

class _TaskDueDateFromAirsyncExt(etree.XSLTExtension):
    def execute(self, context, self_node, input_node, output_parent):
        _task_due_date_from_airsync(input_node, output_parent)

def _task_due_date_from_airsync(input_node, output_parent):
    asdate = tzutils.TaskTextToDate(xml2util.GetNodeValue(input_node))

    if tzconv.curtz() is not None:
        asdate = tzconv.ConvertToLocal(asdate, tzconv.curtz())
        result = asdate.strftime(DATE_FORMAT_VCALTASKLOCAL)
    else:
        nd = xml2util.FindChildNode(input_node.getparent(), "UtcDueDate")
        if nd is not None:
            result = tzutils.TaskTextToDate(xml2util.GetNodeValue(nd)).strftime(DATE_FORMAT_VCALTASK)
        else:
            result = asdate.strftime(DATE_FORMAT_VCALTASKLOCAL)

    content = etree.Element("Content")
    content.text = result
    output_parent.append(content)

def _all_description_from_airsync(context):
    s = xml2util.GetNodeValue(context.context_node)
    asnote = ""
    if len(s) > 0:
        dc = base64.b64decode(s)
        try:
            asnote = pyrtfcomp.RTFConvertToUTF8(dc, 1)
            if isinstance(asnote, bytes):
                try:
                    asnote = asnote.decode('utf-8')
                except UnicodeDecodeError:
                    asnote = asnote.decode('latin-1', errors='replace')
            # pyrtfcomp on Python 3 leaves RTF \'nn escapes partially decoded
            # (backslash consumed but hex code left as 'nn) — fix them here
            asnote = re.sub(r"'([0-9a-fA-F]{2})", lambda m: chr(int(m.group(1), 16)), asnote)
        except pyrtfcomp.RTFException:
            pass
    return asnote

def _all_description_to_airsync(context):
    src_node = context.context_node
    content_node = xml2util.FindChildNode(src_node, "Content")
    s = xml2util.GetNodeValue(content_node)
    ec = ""
    if len(s) > 0:
        try:
            asnote = pyrtfcomp.RTFConvertFromUTF8(s.encode('utf-8'), RTFHDR, 1)
            ec = base64.b64encode(asnote).decode()
        except (pyrtfcomp.RTFException, Exception):
            pass
    return ec

def _all_upper_case(context, string):
    return string.upper()

###############################################################################
# register_xpath_functions
#
# Register Cat.A converter functions via lxml FunctionNamespace

def register_xpath_functions():
    ns = etree.FunctionNamespace("http://synce.org/convert")
    ns.prefix = "convert"
    ns["contact_has_type"]                 = _contact_has_type
    ns["contact_position"]                 = _contact_position
    ns["event_reminder_to_airsync"]        = _event_reminder_to_airsync
    ns["event_reminder_from_airsync"]      = _event_reminder_from_airsync
    ns["event_time_to_airsync"]            = _event_time_to_airsync
    ns["event_datetime_from_airsync"]      = _event_datetime_from_airsync
    ns["event_datetime_short_from_airsync"] = _event_datetime_short_from_airsync
    ns["event_dtstamp_from_now"]           = _event_dtstamp_from_now
    ns["event_alldayevent_to_airsync"]     = _event_alldayevent_to_airsync
    ns["all_description_from_airsync"]     = _all_description_from_airsync
    ns["all_description_to_airsync"]       = _all_description_to_airsync
    ns["all_upper_case"]                   = _all_upper_case
    ns["curtz_name"]                       = _curtz_name

###############################################################################
# get_extension_elements
#
# Returns Cat.B extension element classes (populated in Fase 2b)

def get_extension_elements():
    return {
        ("http://synce.org/convert", "event_starttime_from_airsync"):  _EventStarttimeFromAirsyncExt(),
        ("http://synce.org/convert", "event_endtime_from_airsync"):    _EventEndtimeFromAirsyncExt(),
        ("http://synce.org/convert", "event_recurrence_to_airsync"):   _EventRecurrenceToAirsyncExt(),
        ("http://synce.org/convert", "event_recurrence_from_airsync"): _EventRecurrenceFromAirsyncExt(),
        ("http://synce.org/convert", "task_start_date_to_airsync"):    _TaskStartDateToAirsyncExt(),
        ("http://synce.org/convert", "task_due_date_to_airsync"):      _TaskDueDateToAirsyncExt(),
        ("http://synce.org/convert", "task_start_date_from_airsync"):  _TaskStartDateFromAirsyncExt(),
        ("http://synce.org/convert", "task_due_date_from_airsync"):    _TaskDueDateFromAirsyncExt(),
    }
