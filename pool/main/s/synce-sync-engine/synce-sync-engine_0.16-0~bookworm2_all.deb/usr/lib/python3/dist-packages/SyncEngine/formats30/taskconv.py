# -*- coding: utf-8 -*-
############################################################################
# TASKCONV.py
#
# Dr J A Gow 10/11/2007
#
# XSLT extensions used by tasks only. Contains code split off from the old
# 'conversions' module to keep things a little clearer
#
############################################################################

from lxml import etree
import SyncEngine.xml2util as xml2util
from . import dateutil
from . import tzdatabase
from . import tzutils

DATE_FORMAT_TASK     = '%Y-%m-%dT%H:%M:%S.000'
DATE_FORMAT_VCALTASK = '%Y%m%dT%H%M%S'

###############################################################################
# _DateToAirsyncUTC (Cat.A)

def _DateToAirsyncUTC(context):
    tznode = context.context_node
    date = dateutil.XMLDateTimeToDate(tznode, tzdatabase.tzdb)
    utcdate = date.astimezone(tzutils.tzone.utc)
    return utcdate.strftime(DATE_FORMAT_TASK) + "Z"

###############################################################################
# _DateToAirsyncLocal (Cat.A)

def _DateToAirsyncLocal(context):
    tznode = context.context_node
    date = dateutil.XMLDateTimeToDate(tznode, tzdatabase.tzdb)
    return date.strftime(DATE_FORMAT_TASK) + "Z"

###############################################################################
# _DateFromAirsyncExt (Cat.B)

class _DateFromAirsyncExt(etree.XSLTExtension):
    def execute(self, context, self_node, input_node, output_parent):
        src_node = input_node

        asdate = dateutil.TaskTextToDate(xml2util.GetNodeValue(src_node))
        datetext = asdate.strftime(DATE_FORMAT_VCALTASK)

        curtz = tzdatabase.tzdb.GetCurrentTimezone()
        if curtz is not None:
            output_parent.attrib["TimezoneID"] = curtz.name
        else:
            if xml2util._local_name(src_node.tag) == "StartDate":
                utcdatenode = xml2util.FindChildNode(src_node.getparent(), "UtcStartDate")
            elif xml2util._local_name(src_node.tag) == "DueDate":
                utcdatenode = xml2util.FindChildNode(src_node.getparent(), "UtcDueDate")
            else:
                utcdatenode = None

            if utcdatenode is not None:
                asdate = dateutil.TaskTextToDate(xml2util.GetNodeValue(utcdatenode))
                datetext = asdate.strftime(DATE_FORMAT_VCALTASK) + "Z"

        content = etree.Element("Content")
        content.text = datetext
        output_parent.append(content)

###############################################################################
# _StatusToAirsync (Cat.A)

def _StatusToAirsync(context):
    curnode = context.context_node
    s = xml2util.GetNodeValue(curnode)

    if s == "COMPLETED":
        return "1"
    else:
        # check that PercentComplete == 100% - mark it completed if so
        up = xml2util.FindChildNode(curnode.getparent().getparent(), "PercentComplete")
        if up is not None:
            ct = xml2util.FindChildNode(up, "Content")
            if ct is not None:
                if xml2util.GetNodeValue(ct) == "100":
                    return "1"
    return "0"

###############################################################################
# _StatusFromAirsyncExt (Cat.B)

class _StatusFromAirsyncExt(etree.XSLTExtension):
    def execute(self, context, self_node, input_node, output_parent):
        s = xml2util.GetNodeValue(input_node)
        if s == "1":
            stat_node = etree.Element("Status")
            etree.SubElement(stat_node, "Content").text = "COMPLETED"
            output_parent.append(stat_node)
            pcnt_node = etree.Element("PercentComplete")
            etree.SubElement(pcnt_node, "Content").text = "100"
            output_parent.append(pcnt_node)

###############################################################################
# _PriorityToAirsync (Cat.A)

def _PriorityToAirsync(context):
    d = "0"
    s = xml2util.GetNodeValue(context.context_node)
    if s > "0":
        if s == "7":
            d = "0"
        elif s == "5":
            d = "1"
        elif s == "3":
            d = "2"
        else:
            d = "0"
    return d

###############################################################################
# _PriorityFromAirsync (Cat.A)

def _PriorityFromAirsync(context):
    s = xml2util.GetNodeValue(context.context_node)
    if s == "0":
        return "7"
    elif s == "1":
        return "5"
    elif s == "2":
        return "3"
    else:
        return "0"

###############################################################################
# register_xpath_functions
#
# Register Cat.A task converter functions via lxml FunctionNamespace

def register_xpath_functions():
    ns = etree.FunctionNamespace("http://synce.org/task")
    ns.prefix = "task"
    ns["DateToAirsyncUTC"]   = _DateToAirsyncUTC
    ns["DateToAirsyncLocal"] = _DateToAirsyncLocal
    ns["StatusToAirsync"]    = _StatusToAirsync
    ns["PriorityToAirsync"]  = _PriorityToAirsync
    ns["PriorityFromAirsync"] = _PriorityFromAirsync

###############################################################################
# get_extension_elements
#
# Returns Cat.B extension element classes (populated in Fase 2b)

def get_extension_elements():
    return {
        ("http://synce.org/task", "DateFromAirsync"):   _DateFromAirsyncExt(),
        ("http://synce.org/task", "StatusFromAirsync"): _StatusFromAirsyncExt(),
    }
