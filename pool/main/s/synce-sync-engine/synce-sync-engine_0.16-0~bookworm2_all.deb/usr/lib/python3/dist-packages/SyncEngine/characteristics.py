# -*- coding: utf-8 -*-
############################################################################
#    Copyright (C) 2006  Ole André Vadla Ravnås <oleavr@gmail.com>         #
#    Dr J A Gow 22/11/07 : Split code into new 'Characteristics' module    #
#                                                                          #
#    This program is free software; you can redistribute it and#or modify  #
#    it under the terms of the GNU General Public License as published by  #
#    the Free Software Foundation; either version 2 of the License, or     #
#    (at your option) any later version.                                   #
#                                                                          #
#    This program is distributed in the hope that it will be useful,       #
#    but WITHOUT ANY WARRANTY; without even the implied warranty of        #
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         #
#    GNU General Public License for more details.                          #
#                                                                          #
#    You should have received a copy of the GNU General Public License     #
#    along with this program; if not, write to the                         #
#    Free Software Foundation, Inc.,                                       #
#    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             #
############################################################################

from lxml import etree
from . import xml2util
import logging

logger = logging.getLogger("engine.characteristics")

class Characteristic:

    def __init__(self, type, parent=None):

        self.type = type
        self.params = {}
        self.parent = None
        self.children = {}

    def __getitem__(self, key):
        return self.params[key]

    def __setitem__(self, key, value):
        self.params[key] = value

    def __str__(self):
        return self.to_string()

    def to_string(self, level=0):

        indent = "%*s" % (4 * level, "")
        str = "%s* %s\n" % (indent, self.type)

        if self.params:
            for name, value in list(self.params.items()):
                str += "%s    %s = %s\n" % (indent, name, value)
        else:
            str += "%s    [no params]\n" % indent

        for child in list(self.children.values()):
            str += "\n" + child.to_string(level + 1)

        return str

    def add_child(self, ctic):
        self.children[ctic.type] = ctic


def characteristic_from_xml(xml_node, parent=None):

    ctic = Characteristic(xml2util.GetNodeAttr(xml_node,"type"), parent)

    for child in xml_node:
        if isinstance(child.tag, str):
            local = xml2util._local_name(child.tag)
            if local == "characteristic":
                ctic.children[xml2util.GetNodeAttr(child,"type")] = characteristic_from_xml(child, ctic)
            elif local == "parm":
                ctic[xml2util.GetNodeAttr(child,"name")] = xml2util.GetNodeAttr(child,"value")
            else:
                logger.warning("characteristic_from_xml: Unhandled node '%s'", local)
    return ctic


def characteristic_to_xml(ctic, doc, parent=None):

    node = etree.Element("characteristic")
    node.set("type", ctic.type)

    for child in list(ctic.children.values()):
        characteristic_to_xml(child, doc, node)

    for name, value in list(ctic.params.items()):
        parm = etree.Element("parm")
        parm.set("name", name)
        parm.set("value", value)
        node.append(parm)

    if parent is not None:
        parent.append(node)

    return node


def characteristic_tree_from_xml(node):
    return characteristic_from_xml(node)

def characteristic_tree_to_xml(ctic, doc):
    return characteristic_to_xml(ctic, doc)
